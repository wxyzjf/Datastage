/opt/etl/prd/etl/APP/ADW/B_RELAY42_TX_LIST/bin> cat  b_relay42_list0010.pl
######################################################
#   $Header: /CVSROOT/SmarTone-Vodafone/Code/ETL/APP/Template/b_JobName0010.pl,v 1.1 2005/12/14 01:04:45 MichaelNg Exp $
#   Purpose:
#
#
######################################################

#*#
#my $ETLVAR = $ENV{"AUTO_ETLVAR"};require $ETLVAR;
my $ETLVAR =  "/opt/etl/prd/etl/APP/ADW/B_RELAY42_TX_LIST/bin/master_dev.pl";
require $ETLVAR;


my $MASTER_TABLE = ""; #Please input the final target ADW table name here

sub runSQLPLUS{
  #*#my $SQLCMD_FILE="${etlvar::AUTO_GEN_TEMP_PATH}${etlvar::ETLJOBNAME}_sqlcmd.sql";
  my $SQLCMD_FILE="/opt/etl/prd/etl/APP/ADW/B_RELAY42_TX_LIST/bin/b_relay42_list0010_sqlcmd.sql";#*#
  open SQLCMD, ">" . $SQLCMD_FILE || die "Cannot open file" ;
  print SQLCMD<<ENDOFINPUT;
#*#
whenever sqlerror exit 2;
set serveroutput on;
set sqlblanklines on;
set autocommit 1;
set timing on;
set echo on;
set sqlnumber off;
set define off;
ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD';
#*#

#*#${etlvar::LOGON_TD}
#*#${etlvar::SET_MAXERR}
#*#${etlvar::SET_ERRLVL_1}
#*#${etlvar::SET_ERRLVL_2}

#*#--Please type your SQL statement here
#*#------------------------------------------------------------------------------------------------

#*#EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_RELAY42_LIST_001_TMP');
#*#EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_RELAY42_LIST');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_RELAY42_TX_LIST_001_TMP');
EXECUTE ${etlvar::UTLDB}.ETL_UTILITY.truncate_tbl2(P_schema_tbl_name=>'${etlvar::TMPDB}.B_RELAY42_TX_LIST');
#*#-- DELETE FROM ${etlvar::TMPDB}.B_FBB_RES_COV_REF;
#*#---------------------------------------------------------------------------------------------------


#*#insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.B_RELAY42_LIST_001_TMP
 insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.B_RELAY42_TX_LIST_001_TMP
(
 Acct_Subr_Num_h
,Acct_Subr_Num_e
,Acct_Num_h
,Acct_Num_e
,Subr_Num_h
,Subr_Num_e
,HKID_BR_h
,HKID_BR_e
,Comm_Email_h
,Comm_Email_e
,Comm_Lang
,BILL_Email_h
,BILL_Email_e
,Customer_Type
,Line_Status
,Masked_FLG
,Payment_Method
,PP_Tier
,Loginnow_Status
,Subr_Plan_Name
,Plan_Cat
,Max_LD_Expiry_Date
,RDDP_Flg
,VWE_Flg
,Traval_Past_6mths
,Create_Ts
,Refresh_Ts
,BLACK_LIST_CUST_WRITHOFF_FLG
,BLACK_LIST_CUSTOMER_FLG
,DM_CONSENT_DERIVED_FLG
,REJECT_ALL_COMM_FLG
,D_FREEZE_FLG
,D_FREEZE_FLG_EMAIL
,D_FREEZE_FLG_SMS
,D_LIMITED_CONTACT
,D_LIMITED_CONTACT_EMAIL
,D_LIMITED_CONTACT_SMS
,SUPRT_MMS_FLG
,EMAIL_INTERNET_STUFF_EMAIL_FLG
,EMAIL_INTERNET_STUFF_SMS_FLG
,FUN_STUFF_EMAIL_FLG
,FUN_STUFF_SMS_FLG
,NEWS_FINANCE_INVEST_EMAIL_FLG
,NEWS_FINANCE_INVEST_SMS_FLG
,SENSITIVE_SUBJECT_EMAIL_FLG
,SENSITIVE_SUBJECT_SMS_FLG
,SPECIAL_OFFER_EMAIL_FLG
,SPECIAL_OFFER_SMS_FLG
)
select 
 Acct_Subr_Num_h
,Acct_Subr_Num_e
,Acct_Num_h
,Acct_Num_e
,Subr_Num_h
,Subr_Num_e
,HKID_BR_h
,HKID_BR_e
,Comm_Email_h
,Comm_Email_e
,Comm_Lang
,BILL_Email_h
,BILL_Email_e
,Customer_Type
,Line_Status
,Masked_FLG
,Payment_Method
,PP_Tier
,Loginnow_Status
,Subr_Plan_Name
,Plan_Cat
,Max_LD_Expiry_Date
,RDDP_Flg
,VWE_Flg
,Traval_Past_6mths
,Create_Ts
,Refresh_Ts
,BLACK_LIST_CUST_WRITHOFF_FLG
,BLACK_LIST_CUSTOMER_FLG
,DM_CONSENT_DERIVED_FLG
,REJECT_ALL_COMM_FLG
,D_FREEZE_FLG
,D_FREEZE_FLG_EMAIL
,D_FREEZE_FLG_SMS
,D_LIMITED_CONTACT
,D_LIMITED_CONTACT_EMAIL
,D_LIMITED_CONTACT_SMS
,SUPRT_MMS_FLG
,EMAIL_INTERNET_STUFF_EMAIL_FLG
,EMAIL_INTERNET_STUFF_SMS_FLG
,FUN_STUFF_EMAIL_FLG
,FUN_STUFF_SMS_FLG
,NEWS_FINANCE_INVEST_EMAIL_FLG
,NEWS_FINANCE_INVEST_SMS_FLG
,SENSITIVE_SUBJECT_EMAIL_FLG
,SENSITIVE_SUBJECT_SMS_FLG
,SPECIAL_OFFER_EMAIL_FLG
,SPECIAL_OFFER_SMS_FLG
from ${etlvar::ADWDB}.RELAY42_LIST
;



#*#insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.B_RELAY42_LIST
insert /*+ APPEND parallel(64) */ into ${etlvar::TMPDB}.B_RELAY42_TX_LIST
(
 Acct_Subr_Num_h
,Acct_Subr_Num_e
,Acct_Num_h
,Acct_Num_e
,Subr_Num_h
,Subr_Num_e
,HKID_BR_h
,HKID_BR_e
,Comm_Email_h
,Comm_Email_e
,Comm_Lang
,BILL_Email_h
,BILL_Email_e
,Customer_Type
,Line_Status
,Masked_FLG
,Payment_Method
,PP_Tier
,Loginnow_Status
,Subr_Plan_Name
,Plan_Cat
,Max_LD_Expiry_Date
,RDDP_Flg
,VWE_Flg
,Traval_Past_6mths
,Create_Ts
,Refresh_Ts
,BLACK_LIST_CUST_WRITHOFF_FLG
,BLACK_LIST_CUSTOMER_FLG
,DM_CONSENT_DERIVED_FLG
,REJECT_ALL_COMM_FLG
,D_FREEZE_FLG
,D_FREEZE_FLG_EMAIL
,D_FREEZE_FLG_SMS
,D_LIMITED_CONTACT
,D_LIMITED_CONTACT_EMAIL
,D_LIMITED_CONTACT_SMS
,SUPRT_MMS_FLG
,EMAIL_INTERNET_STUFF_EMAIL_FLG
,EMAIL_INTERNET_STUFF_SMS_FLG
,FUN_STUFF_EMAIL_FLG
,FUN_STUFF_SMS_FLG
,NEWS_FINANCE_INVEST_EMAIL_FLG
,NEWS_FINANCE_INVEST_SMS_FLG
,SENSITIVE_SUBJECT_EMAIL_FLG
,SENSITIVE_SUBJECT_SMS_FLG
,SPECIAL_OFFER_EMAIL_FLG
,SPECIAL_OFFER_SMS_FLG
)
Select
a.Cust_Num ||'|'|| a.Subr_Num as Acct_Subr_Num_h
,a.Cust_Num ||'|'|| a.Subr_Num as Acct_Subr_Num_e
,a.Cust_Num as Acct_Num_h
,a.Cust_Num as Acct_Num_e
,a.Subr_Num as Subr_Num_h
,a.Subr_Num as Subr_Num_e
,coalesce(b.HKID_BR,' ') as HKID_BR_h
,coalesce(b.HKID_BR,' ') as HKID_BR_e
,coalesce(c.Corr_Email,' ') as Comm_Email_h
,coalesce(c.Corr_Email ,' ') as Comm_Email_e
,coalesce(c.Corr_Email_Lang,' ') as COMM_LANG
,coalesce(c.Bill_Email,' ') as BILL_EMAIL_h
,coalesce(c.Bill_Email,' ') as BILL_EMAIL_e
,CASE WHEN b.Id_Type_Cd ='I' THEN 'HKID'   yyyId_Type_Cd CHAR(1 Byte)
      WHEN b.Id_Type_Cd ='P' THEN 'Passport'
      WHEN b.Id_Type_Cd ='B' THEN 'BR'
      WHEN b.Id_Type_Cd ='S' THEN 'SMC'
      WHEN b.Id_Type_Cd ='N' THEN 'NOBR'
      WHEN b.Id_Type_Cd ='G' THEN 'G - Government' 
 ELSE ' '
 END Customer_Type
,CASE WHEN a.Subr_Stat_Cd ='OK' THEN 'Active'
      WHEN a.Subr_Stat_Cd ='PE' THEN 'Pending'
      WHEN a.Subr_Stat_Cd ='SU' THEN 'Suspended'
      WHEN a.Subr_Stat_Cd ='TX' THEN 'Terminated'
 ELSE ' '
END Line_Status
,CASE WHEN a.MASKED ='MASKED'THEN 'Y' ELSE 'N' END MASKED_FLG
,b.Payment_Meth_Cd as PAYMENT_METHOD
,coalesce(e.membership_tier ,' ') as PP_TIER
,CASE WHEN b.LoginNow_Ind ='Y' THEN 'Owner'
      WHEN b.LoginNow_Ind ='P' THEN 'User'
 ELSE ' ' END loginnow_status            
,coalesce(f.RATE_PLAN_DESC,' ')  as Subr_Plan_Name
,CASE WHEN (g.Shk_Plan_Subgrp is null OR g.Shk_Plan_Subgrp = 'Other plans (e.g. other voice plan, MBB plans)') THEN
              CASE
                   WHEN  a.Line_Cat ='B' THEN 'MBB/Vanquish'
                   WHEN  a.Line_Cat ='F' THEN 'HP+'
                   WHEN  a.Line_Cat ='H' THEN 'HKBN'
                   WHEN  a.Line_Cat ='I' THEN '1638'
                   WHEN  a.Line_Cat ='L' THEN 'HomeTel'
                   WHEN  a.Line_Cat ='M' THEN 'Mobile'
                   WHEN  a.Line_Cat ='P' THEN 'NSP'
                   WHEN  a.Line_Cat ='R' THEN 'FBB'
                   WHEN  a.Line_Cat ='X' THEN 'Postpaid HP+'
                   ELSE  a.Line_Cat
              END
      WHEN g.Shk_Plan_Subgrp is not null  THEN
              CASE WHEN g.Shk_Plan_Subgrp <>'Other plans (e.g. other voice plan, MBB plans)' THEN   g.Shk_Plan_Subgrp 
              END
   END plan_cat
,coalesce(h.Ld_Expired_Date,to_date('${etlvar::MAXDATE}','YYYY-MM-DD') ) as MAX_LD_Expiry_Date
,coalesce(j.RDDP_FLG,'N' ) as RDDP_FLG
,coalesce(k.VWE_FLG,'N' ) as VWE_FLG
,CASE WHEN l.Subr_Num is null Then 'N' ELSE 'Y' END Traval_Past_6mths
,TO_TIMESTAMP('${etlvar::LOADTIME}','YYYY-MM-DD HH24:MI:SS') as Create_Ts
,TO_TIMESTAMP('${etlvar::LOADTIME}','YYYY-MM-DD HH24:MI:SS') as Refresh_Ts
,coalesce(n.BLACK_LIST_CUST_WRITHOFF_FLG,'N')
,coalesce(n.BLACK_LIST_CUSTOMER_FLG,'N')
,coalesce(x.DM_CONSENT_DERIVED_FLG,'N')
,case when c.Reject_All_Comm_Flg = 'N' then 'Y' else 'N' end  
,coalesce(x1.D_Freeze_Flg, 'N')
,coalesce(x3.D_Freeze_Flg, 'N')
,coalesce(x2.D_Freeze_Flg, 'N')
,coalesce(x1.D_Limited_Contact, 'N')
,coalesce(x3.D_Limited_Contact, 'N')
,coalesce(x2.D_LIMITED_CONTACT, 'N')
,coalesce(x5.SUPRT_MMS_FLG, 'N')
,coalesce(c.EMAIL_INTERNET_STUFF_EMAIL_FLG,'N')
,coalesce(c.EMAIL_INTERNET_STUFF_SMS_FLG,'N')
,coalesce(c.FUN_STUFF_EMAIL_FLG,'N')
,coalesce(c.FUN_STUFF_SMS_FLG,'N')
,coalesce(c.NEWS_FINANCE_INVEST_EMAIL_FLG,'N')
,coalesce(c.NEWS_FINANCE_INVEST_SMS_FLG,'N')
,coalesce(c.SENSITIVE_SUBJECT_EMAIL_FLG,'N')
,coalesce(c.SENSITIVE_SUBJECT_SMS_FLG,'N')
,coalesce(c.SPECIAL_OFFER_EMAIL_FLG,'N')
,coalesce(c.SPECIAL_OFFER_SMS_FLG,'N')
FROM
(select * from ${etlvar::ADWDB}.SUBR_INFO_HIST Where  to_date('${etlvar::TXDATE}','YYYY-MM-DD') -1 between Start_Date and End_Date
#*#--and subr_stat_cd <>'TX'
#*#AND  subr_stat_cd in ('SU' ,'TX')
#*#AND  subr_stat_cd in ('SU' ,'TX')
#*#AND  subr_stat_cd = 'OK'
#*#AND  subr_stat_cd in ('SU' ,'TX')
AND  Subr_Sw_Off_Date >= ADD_MONTHS(TO_DATE('${etlvar::TXMONTH}','YYYYMM'),-12)
AND  line_cat <> 'I'
) a 
LEFT OUTER JOIN
(select * from ${etlvar::ADWDB}.CUST_INFO_HIST  where  to_date('${etlvar::TXDATE}','YYYY-MM-DD') -1 between Start_Date and End_Date ) b
ON  a.Cust_Num = b.Cust_Num
LEFT OUTER JOIN
${etlvar::ADWDB}.SUBR_EMAIL c
ON  a.Cust_Num = c.Cust_Num
and a.Subr_Num = c.Subr_Num
LEFT OUTER JOIN
(select * from ${etlvar::ADWDB}.SUBR_LOYALTY_MARKER_HIST  where  to_date('${etlvar::TXDATE}','YYYY-MM-DD') -1 between Start_Date and End_Date ) d
ON  a.Cust_Num = d.Cust_Num
and a.Subr_Num = d.Subr_Num
LEFT OUTER JOIN
  (select distinct CASE WHEN membership_tier ='Red' Then 'Plus' ELSE membership_tier END membership_tier,Marker from ${etlvar::ADWDB}.PP_MEMBERSHIP_MARKER_REF) e
ON  d.marker = e.marker
LEFT OUTER JOIN
${etlvar::ADWDB}.RATE_PLAN_COGNOS_REF f 
ON a.Rate_Plan_Cd =f.Rate_Plan_Cd
LEFT OUTER JOIN 
${etlvar::ADWDB}.SHK_RATE_PLAN_GRP_REF g
ON f.FREE_DATA_ENTITLE = g.FREE_DATA_ENTITLE
LEFT OUTER JOIN 
(SELECT  cust_num,subr_num,inv_num,ld_cd,mkt_cd,Ld_Expired_Date
         ,       ROW_NUMBER() OVER (PARTITION BY Subr_Num ,Cust_Num ORDER BY Ld_Expired_Date  DESC )  rn
  FROM   (select cust_num,subr_num,inv_num,ld_cd,mkt_cd,Ld_Expired_Date
          FROM ${etlvar::ADWDB}.SUBR_LD 
          where  void_flg <> 'Y'
         ) a
) h
ON  a.Cust_Num = h.Cust_Num
and a.Subr_Num = h.Subr_Num
AND h.rn=1
LEFT OUTER JOIN
(
select a.cust_num,a.subr_num,a.RDDP_FLG
 ,       ROW_NUMBER() OVER (PARTITION BY a.Subr_Num ,a.Cust_Num ORDER BY RDDP_FLG  DESC )  rn
 from 
(select i.cust_num,i.subr_num 
,CASE WHEN j.Bill_Cd is null Then 'N' ELSE 'Y' END RDDP_FLG 
from
(select * from ${etlvar::ADWDB}.BILL_SERVS  where  to_date('${etlvar::TXDATE}','YYYY-MM-DD') -1 between Bill_Start_Date and Bill_End_Date ) i
LEFT OUTER JOIN
${etlvar::ADWDB}.RELAY42_RDDP_BILLCD_REF j 
ON i.BILL_SERV_CD = j.Bill_Cd
) a ) j
ON  a.Cust_Num = j.Cust_Num
and a.Subr_Num = j.Subr_Num
AND j.rn=1
LEFT OUTER JOIN
(
select a.cust_num,a.subr_num,a.VWE_FLG
 ,       ROW_NUMBER() OVER (PARTITION BY a.Subr_Num ,a.Cust_Num ORDER BY VWE_FLG  DESC )  rn
 from 
(select i.cust_num,i.subr_num 
,CASE WHEN j.Bill_Cd is null Then 'N' ELSE 'Y' END VWE_FLG
from
(select * from ${etlvar::ADWDB}.BILL_SERVS  where  to_date('${etlvar::TXDATE}','YYYY-MM-DD') -1 between Bill_Start_Date and Bill_End_Date ) i
LEFT OUTER JOIN
${etlvar::ADWDB}.RELAY42_VWE_BILLCD_REF j 
ON i.BILL_SERV_CD = j.Bill_Cd
) a ) k
ON  a.Cust_Num = k.Cust_Num
and a.Subr_Num = k.Subr_Num
AND k.rn=1
LEFT OUTER JOIN
(select Cust_Num,Subr_Num,count(*) cnt 
 ${etlvar::BIZDB}.BM_LIS_ROAM_SUMM where trx_month between add_months(TO_DATE('${etlvar::TXMONTH}','YYYYMM'),-6) AND TO_DATE('${etlvar::TXMONTH}','YYYYMM')-1  group by Cust_Num,Subr_Num) l
ON  a.Cust_Num = l.Cust_Num
AND a.Subr_Num = l.Subr_Num
LEFT OUTER JOIN
           ${etlvar::BIZVW}.VW_KPI_ALL_CA_BR_LIST m
on m.Hkid_Br_Prefix = b.Hkid_Br_Prefix
LEFT OUTER JOIN
           (select distinct b.CUST_NUM 
                            ,b.Hkid_Br_Prefix
                                ,case when a.Hkid_Br_Prefix=' '  or a.Hkid_Br_Prefix is null then 'N' 
                                else a.D_WrithOff_Flg end  BLACK_LIST_CUST_WRITHOFF_FLG
                                , b.D_Black_List_Flg BLACK_LIST_CUSTOMER_FLG
                                 from (
                                select D_BLACK_LIST_FLG D_Black_List_Flg, HKID_BR_PREFIX Hkid_Br_Prefix,CUST_NUM
                                 from ${etlvar::BIZVW}.VW_CUST_MISC_INFO) b 
                                 LEFT OUTER JOIN (
                                select a.D_WRITHOFF_FLG D_WrithOff_Flg, a.HKID_BR_PREFIX Hkid_Br_Prefix
                                 from ${etlvar::BIZVW}.VW_BLACK_LIST_WRITEOFF a) a 
                                 on b.Hkid_Br_Prefix=a.Hkid_Br_Prefix ) n
on n.Hkid_Br_Prefix = b.Hkid_Br_Prefix
AND a.Cust_Num = n.Cust_Num
LEFT OUTER JOIN
${etlvar::BIZVW}.VW_DM_CONSENT_DERIVED x
ON  a.Cust_Num = x.Cust_Num
AND a.Subr_Num = x.Subr_Num
LEFT OUTER JOIN 
${etlvar::BIZVW}.VW_OPT_OUT_INFO x1
ON a.Cust_Num=x1.Cust_Num
AND a.Subr_Num=x1.Subr_Num
LEFT OUTER JOIN 
${etlvar::BIZVW}.VW_OPT_OUT_SMS_INFO x2
ON a.Cust_Num=x2.Cust_Num 
AND a.Subr_Num=x2.Subr_Num
LEFT OUTER JOIN 
${etlvar::BIZVW}.VW_OPT_OUT_EMAIL_INFO x3
ON a.Cust_Num=x3.Cust_Num
AND a.Subr_Num=x3.Subr_Num
LEFT OUTER JOIN 
${etlvar::BIZVW}.VW_SUBR_HS_USG x5 
ON a.Cust_Num=x5.CUST_NUM
AND a.Subr_Num=x5.SUBR_NUM
WHERE (m.Hkid_Br_Prefix is null OR m.CM_Norminate_Flg = 'N')
;

COMMIT;


exit;
ENDOFINPUT
  close(SQLCMD);
  print("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  my $ret = system("sqlplus /\@${etlvar::TDDSN} \@$SQLCMD_FILE");
  if ($ret != 0)
  {
    return (1);
  }
  return 0;

}




#We need to have variable input for the program to start
if ($#ARGV < 0){
    print("Syntax : perl <Script Name> <System Name>_<Job Name>_<TXDATE>.dir>\n");
    print("Example: perl b_cust_info0010.pl adw_b_cust_info_20051010.dir\n");
    exit(1);
}




#Call the function we want to run
open(STDERR, ">&STDOUT");

my $pre = etlvar::preProcess($ARGV[0]);
my $rc = etlvar::getTXDate($MASTER_TABLE);
my $ret = runSQLPLUS();
my $post = etlvar::postProcess();

exit($ret);


