/opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin> cat testing.pl
#!/usr/bin/perl -w
use Digest::SHA qw(sha256); # hash SHA-256  algorithm
use MIME::Base64;
use strict;
use Crypt::CBC; # AES 256  algorithm
use Config;

#
# $Header: dw_unpack_mscfile.pl,v 1.1 2005/08/29 14:43:25 dwbat Exp $
#
# $Locker: dwbat $
#
# $Log: dw_unpack_mscfile.pl,v $
# Revision 1.1  2005/08/29  14:43:25  14:43:25  dwbat (Data Warehouse Batch Job User (Oracle))
# Initial revision

#Revision 1.1  2004/11/17  19:57:12  19:57:12  dwbat (DW Batch Job Account)
#Initial revision
#
#
#
#$checksum = 0;
my $salt = "Relay42#SMC".q(@)."Nov2018"; # hash SHA-256  algorithm
my $passphrase = "SMCRelay42Nov2018";  # AES 256  algorithm

my $Subr_Num_hs="97282214";
my $HKID_BR_h="SVP00009";
my $Subr_Num_h="97282214";
my $Subr_Num_h1=unpack("H*", sha256($Subr_Num_hs,$salt));chomp ($Subr_Num_h1);
my $HKID_BR_h1=unpack("H*", sha256($HKID_BR_h,$salt));chomp ($HKID_BR_h1);
print "$Subr_Num_h1\n";
print "$HKID_BR_h1\n";
#hash without salt
my $Subr_Num_h2=unpack("H*", sha256($Subr_Num_h));chomp ($Subr_Num_h2);
print "$Subr_Num_h2\n";

##die "Check Sum Error" if $checksum != 0;

