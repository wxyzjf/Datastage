/opt/etl/prd/etl/APP/RPT/U_RELAY42_TX_GEN_RPT/bin> cat encrypt_4.pl
#!/usr/bin/perl
use MIME::Base64;
use strict;
use Crypt::CBC;
use Config;

sub encrypt {
  my ($plain_text, $passphrase) = @_;
  my $pbe = Crypt::CBC->new(
     -key => $passphrase,
     -cipher  => 'Crypt::Rijndael',
     -keysize => 128/8,
  );
  my $cipher_text = $pbe->encrypt($plain_text);
  my $encrypted_text = encode_base64($cipher_text);
  return $encrypted_text;
}

sub decrypt {
  my ($encrypted_text, $passphrase) = @_;
  my $cipher_text = decode_base64($encrypted_text);
  my $pbe = Crypt::CBC->new(
     -key => $passphrase,
     -cipher => 'Crypt::Rijndael',
     -keysize => 128/8,
  );
  my $plain_text = $pbe->decrypt($cipher_text);
  return $plain_text;
}
#my $str='johnson_cheung@smartone.com';
 my $password='SMCRelay42Nov2018';

# my $encrypted = encrypt($str, $password);
# print "encrypted:." . $encrypted . "\n";


#$encrypted='U2FsdGVkX1+MgVOeMAIL/XZ5oADhVTQ7Z8rnkhtzGbF4k46s4AbgpaIXJeRDbpzF';
#my $str='trust.me.cally.i.75460@gmail.com';
 my $str='trust.me.cally.iu79460@gmail.com';
 #my $str='Thisisatesting';
 #my $str='DWSupport';
 #my $str='StoneShek';
 #my $str='JohnsonCheung';

# $encrypted='';
print "input:.". $str. "\n";
 my $encrypted =encrypt($str, $password);
$encrypted =~ s/\n//;
#$encrypted =~ s/\n//;
print "encrypted:." . $encrypted . "\n";

print "Length encrypted:." .length($encrypted) . "\n"; 
#chomp($encrypted);
chomp($encrypted);
print "chomp encrypted:." . $encrypted . "\n";
print "Lengthchomp encrypted:." . length($encrypted) . "\n";
#my $test2= chomp($test1);
 #print "encrypted:." . $encrypted . "\n";
 #print "chomp encrypted:." . $encrypted . "\n";
# print "test2:." . $test1. "\n";
 # my $decrypted = decrypt($encrypted, $password);
 #  print "decrypted:." . $decrypted . "\n";

